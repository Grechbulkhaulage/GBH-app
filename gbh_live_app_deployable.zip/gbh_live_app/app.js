const storageKey = "gbh-live-app-data-v1";
const defaultData = {
  drivers: ["Timothy Grech", "Barry Kibblewhite", "Thomas Harvey", "Lyam Drummond", "Orkhan Combe", "John Gurdler"],
  trucks: ["TGRECH", "TIMMYG", "XP17NK"],
  customers: ["ANA", "Downer", "Spray Seal", "HVIS", "Tefol"],
  docketCounter: 1001,
  dockets: [],
  timeLogs: [],
  activeShift: null,
  chatMessages: [
    { user: "Admin", text: "Welcome to the GBH operations app.", time: new Date().toISOString() },
    { user: "Timothy Grech", text: "Roster and dockets are ready for this week.", time: new Date().toISOString() }
  ],
  photos: [],
  rosterWeekStart: getSunday(new Date()).toISOString().slice(0, 10),
  rosterRows: [
    { unit: "402 Baz", shift: "Day Shift", jobs: ["", "ANA - Baz", "HVIS - Baz", "ANA - Baz", "ANA - Baz", "ANA - Baz", "ANA - Baz"] },
    { unit: "402 Baz", shift: "Night Shift", jobs: ["ANA - Baz", "ANA - Lyam", "ANA - Baz", "ANA - Baz", "ANA - Baz", "", ""] },
    { unit: "358 Tim", shift: "Day Shift", jobs: ["", "", "ANA - Tim", "ANA - Tim", "ANA - Tim", "ANA - Tim", "ANA - Tim"] },
    { unit: "358 Tim", shift: "Night Shift", jobs: ["ANA - Tim", "ANA - Tim", "ANA - Tim", "ANA - Tim", "ANA - Tim", "", ""] },
    { unit: "359", shift: "Day Shift", jobs: ["", "", "ANA - Tom", "ANA - Tom", "ANA - Tom", "ANA - Tom", "ANA - Tom"] },
    { unit: "359", shift: "Night Shift", jobs: ["ANA - Tom", "ANA - Orkhan", "ANA - Orkhan", "ANA - Lyam", "ANA - Orkhan", "", ""] }
  ]
};

const state = {
  data: loadData(),
  currentUser: null,
  deferredPrompt: null
};

const els = {};

document.addEventListener("DOMContentLoaded", () => {
  bindElements();
  populateLoginUsers();
  attachEvents();
  renderAll();
  updateClock();
  setInterval(updateClock, 1000);
});

function bindElements() {
  [
    "loginView","appView","loginForm","roleSelect","userSelect","passwordInput","logoutBtn","activeUserName","activeUserRole",
    "userInitials","todayDate","openDocketsCount","photoCount","chatCount","activityFeed","dashboardRoster","weekStartInput",
    "rosterTable","resetRosterBtn","docketForm","docketNumber","docketDate","docketDriver","docketTruck","docketCustomer",
    "jobDescription","startTime","finishTime","travelHours","totalHours","preStartStatus","faultComments","driverSignature",
    "docketList","liveClock","clockInBtn","clockOutBtn","clockStatus","dutyDescription","timesheetCustomer","timesheetTruck",
    "timesheetLog","chatMessages","chatForm","chatInput","photoForm","photoFileInput","photoGallery","installBtn"
  ].forEach(id => els[id] = document.getElementById(id));
}

function loadData() {
  const raw = localStorage.getItem(storageKey);
  if (!raw) return structuredClone(defaultData);
  try {
    return { ...structuredClone(defaultData), ...JSON.parse(raw) };
  } catch {
    return structuredClone(defaultData);
  }
}

function saveData() {
  localStorage.setItem(storageKey, JSON.stringify(state.data));
}

function getSunday(date) {
  const d = new Date(date);
  const day = d.getDay();
  d.setDate(d.getDate() - day);
  d.setHours(0,0,0,0);
  return d;
}

function populateLoginUsers() {
  const role = els.roleSelect.value;
  const options = role === "admin" ? ["admin"] : state.data.drivers;
  els.userSelect.innerHTML = options.map(name => `<option value="${name}">${name}</option>`).join("");
}

function attachEvents() {
  els.roleSelect.addEventListener("change", populateLoginUsers);
  els.loginForm.addEventListener("submit", handleLogin);
  els.logoutBtn.addEventListener("click", logout);
  document.querySelectorAll(".nav-btn").forEach(btn => btn.addEventListener("click", () => switchSection(btn.dataset.target)));
  els.weekStartInput.addEventListener("change", () => {
    state.data.rosterWeekStart = els.weekStartInput.value;
    saveData();
    renderRoster();
  });
  els.resetRosterBtn.addEventListener("click", () => {
    state.data.rosterRows = structuredClone(defaultData.rosterRows);
    saveData();
    renderRoster();
  });
  els.docketForm.addEventListener("submit", saveDocket);
  els.clockInBtn.addEventListener("click", clockIn);
  els.clockOutBtn.addEventListener("click", clockOut);
  els.chatForm.addEventListener("submit", sendChat);
  els.photoForm.addEventListener("submit", uploadPhotos);
  document.querySelectorAll(".inline-form").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      const listKey = form.dataset.list;
      const input = form.querySelector("input");
      const value = input.value.trim();
      if (!value) return;
      state.data[listKey].push(value);
      input.value = "";
      saveData();
      renderAll();
    });
  });

  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    state.deferredPrompt = e;
    els.installBtn.classList.remove("hidden");
  });

  els.installBtn.addEventListener("click", async () => {
    if (!state.deferredPrompt) return;
    state.deferredPrompt.prompt();
    await state.deferredPrompt.userChoice;
    state.deferredPrompt = null;
    els.installBtn.classList.add("hidden");
  });

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js");
  }
}

function handleLogin(e) {
  e.preventDefault();
  const pin = els.passwordInput.value.trim();
  if (pin !== "1234") {
    alert("Incorrect PIN. Use 1234 for the demo.");
    return;
  }
  const role = els.roleSelect.value;
  const name = els.userSelect.value;
  state.currentUser = { role, name: role === "admin" ? "Admin" : name };
  els.loginView.classList.remove("active");
  els.appView.classList.add("active");
  els.logoutBtn.classList.remove("hidden");
  document.querySelectorAll(".admin-only, .admin-only-section").forEach(el => {
    el.classList.toggle("hidden", role !== "admin");
  });
  updateUserBadge();
  switchSection("dashboardSection");
  renderAll();
}

function logout() {
  state.currentUser = null;
  els.appView.classList.remove("active");
  els.loginView.classList.add("active");
  els.logoutBtn.classList.add("hidden");
}

function updateUserBadge() {
  const user = state.currentUser;
  els.activeUserName.textContent = user.name;
  els.activeUserRole.textContent = user.role === "admin" ? "Administrator" : "Driver";
  els.userInitials.textContent = user.name.split(" ").map(v => v[0]).join("").slice(0,2).toUpperCase();
}

function switchSection(targetId) {
  document.querySelectorAll(".content-section").forEach(section => section.classList.remove("active"));
  document.getElementById(targetId).classList.add("active");
  document.querySelectorAll(".nav-btn").forEach(btn => btn.classList.toggle("active", btn.dataset.target === targetId));
}

function renderAll() {
  renderDropdowns();
  renderDashboard();
  renderRoster();
  renderDockets();
  renderTimeLogs();
  renderChat();
  renderPhotos();
  renderSettings();
}

function renderDropdowns() {
  [els.docketDriver].forEach(select => {
    select.innerHTML = state.data.drivers.map(v => `<option>${v}</option>`).join("");
  });
  [els.docketTruck, els.timesheetTruck].forEach(select => {
    select.innerHTML = state.data.trucks.map(v => `<option>${v}</option>`).join("");
  });
  [els.docketCustomer, els.timesheetCustomer].forEach(select => {
    select.innerHTML = state.data.customers.map(v => `<option>${v}</option>`).join("");
  });
  els.docketDate.value = new Date().toISOString().slice(0, 10);
  els.docketNumber.value = state.data.docketCounter;
  if (state.currentUser?.role === "driver") {
    els.docketDriver.value = state.currentUser.name;
  }
}

function renderDashboard() {
  els.todayDate.textContent = new Date().toLocaleDateString("en-AU", { day: "2-digit", month: "short", year: "numeric" });
  els.openDocketsCount.textContent = state.data.dockets.length;
  els.photoCount.textContent = state.data.photos.length;
  els.chatCount.textContent = state.data.chatMessages.length;

  const upcoming = state.data.rosterRows.slice(0, 4).map(row => `
    <div class="list-item"><strong>${row.unit} · ${row.shift}</strong><br><span class="muted">${row.jobs.filter(Boolean).slice(0, 4).join(" · ") || "No jobs assigned"}</span></div>
  `).join("");
  els.dashboardRoster.innerHTML = upcoming;

  const items = [];
  if (state.data.dockets[0]) items.push(`Latest docket #${state.data.dockets[0].docketNumber} saved for ${state.data.dockets[0].customer}.`);
  if (state.data.timeLogs[0]) items.push(`${state.data.timeLogs[0].driver} logged ${state.data.timeLogs[0].duration || "active shift"}.`);
  if (state.data.photos[0]) items.push(`${state.data.photos[0].user} uploaded photo(s).`);
  items.push("Sunday to Saturday roster loaded.");
  els.activityFeed.innerHTML = items.map(item => `<li>${item}</li>`).join("");
}

function renderRoster() {
  els.weekStartInput.value = state.data.rosterWeekStart;
  const start = new Date(state.data.rosterWeekStart);
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
  const thead = `
    <tr>
      <th>Unit</th>
      <th>Shift</th>
      ${days.map(d => `<th>${d.toLocaleDateString("en-AU", { weekday: "short", day: "2-digit", month: "short" })}</th>`).join("")}
    </tr>`;
  const tbody = state.data.rosterRows.map((row, rowIndex) => `
    <tr>
      <td>${row.unit}</td>
      <td>${row.shift}</td>
      ${row.jobs.map((job, idx) => `<td contenteditable="${state.currentUser?.role === "admin"}" data-row="${rowIndex}" data-col="${idx}" class="roster-cell">${job || ""}</td>`).join("")}
    </tr>`).join("");
  els.rosterTable.querySelector("thead").innerHTML = thead;
  els.rosterTable.querySelector("tbody").innerHTML = tbody;
  els.rosterTable.querySelectorAll(".roster-cell").forEach(cell => {
    cell.addEventListener("blur", () => {
      if (state.currentUser?.role !== "admin") return;
      const row = Number(cell.dataset.row);
      const col = Number(cell.dataset.col);
      state.data.rosterRows[row].jobs[col] = cell.textContent.trim();
      saveData();
    });
  });
}

function saveDocket(e) {
  e.preventDefault();
  const entry = {
    docketNumber: state.data.docketCounter,
    date: els.docketDate.value,
    driver: els.docketDriver.value,
    truck: els.docketTruck.value,
    customer: els.docketCustomer.value,
    jobDescription: els.jobDescription.value,
    startTime: els.startTime.value,
    finishTime: els.finishTime.value,
    travelHours: els.travelHours.value,
    totalHours: els.totalHours.value,
    preStartStatus: els.preStartStatus.value,
    faultComments: els.faultComments.value,
    driverSignature: els.driverSignature.value || els.docketDriver.value,
    createdAt: new Date().toISOString()
  };
  state.data.dockets.unshift(entry);
  state.data.docketCounter += 1;
  saveData();
  els.docketForm.reset();
  renderAll();
}

function renderDockets() {
  els.docketList.innerHTML = state.data.dockets.length ? state.data.dockets.map(d => `
    <article class="list-item">
      <strong>Docket #${d.docketNumber} · ${d.customer}</strong>
      <div class="muted">${d.date} · ${d.driver} · ${d.truck}</div>
      <p>${d.jobDescription || "No job description supplied."}</p>
      <small>Start ${d.startTime || "-"} · Finish ${d.finishTime || "-"} · Total ${d.totalHours || "0"} hrs</small>
    </article>`).join("") : '<div class="list-item">No dockets saved yet.</div>';
}

function updateClock() {
  els.liveClock.textContent = new Date().toLocaleTimeString("en-AU");
}

function clockIn() {
  if (!state.currentUser) return;
  if (state.data.activeShift) {
    alert("A shift is already active.");
    return;
  }
  state.data.activeShift = {
    driver: state.currentUser.name,
    start: new Date().toISOString(),
    dutyDescription: els.dutyDescription.value,
    customer: els.timesheetCustomer.value,
    truck: els.timesheetTruck.value
  };
  saveData();
  renderTimeLogs();
}

function clockOut() {
  if (!state.data.activeShift) {
    alert("No active shift found.");
    return;
  }
  const end = new Date();
  const start = new Date(state.data.activeShift.start);
  const hours = ((end - start) / 36e5).toFixed(2);
  state.data.timeLogs.unshift({
    ...state.data.activeShift,
    end: end.toISOString(),
    duration: `${hours} hrs`
  });
  state.data.activeShift = null;
  saveData();
  renderAll();
}

function renderTimeLogs() {
  els.clockStatus.textContent = state.data.activeShift
    ? `${state.data.activeShift.driver} clocked in at ${new Date(state.data.activeShift.start).toLocaleTimeString("en-AU")}.`
    : "Not currently clocked in.";
  els.timesheetLog.innerHTML = state.data.timeLogs.length ? state.data.timeLogs.map(log => `
    <article class="list-item">
      <strong>${log.driver}</strong>
      <div class="muted">${new Date(log.start).toLocaleDateString("en-AU")} · ${log.customer} · ${log.truck}</div>
      <p>${log.dutyDescription || "No duty description"}</p>
      <small>${new Date(log.start).toLocaleTimeString("en-AU")} to ${new Date(log.end).toLocaleTimeString("en-AU")} · ${log.duration}</small>
    </article>`).join("") : '<div class="list-item">No completed shifts yet.</div>';
}

function sendChat(e) {
  e.preventDefault();
  const text = els.chatInput.value.trim();
  if (!text || !state.currentUser) return;
  state.data.chatMessages.push({ user: state.currentUser.name, text, time: new Date().toISOString() });
  els.chatInput.value = "";
  saveData();
  renderChat();
  renderDashboard();
}

function renderChat() {
  els.chatMessages.innerHTML = state.data.chatMessages.map(msg => `
    <div class="chat-msg">
      <strong>${msg.user}</strong>
      <div>${msg.text}</div>
      <small>${new Date(msg.time).toLocaleString("en-AU")}</small>
    </div>`).join("");
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
}

function uploadPhotos(e) {
  e.preventDefault();
  const files = Array.from(els.photoFileInput.files || []);
  if (!files.length || !state.currentUser) return;
  Promise.all(files.map(file => readFileAsDataUrl(file).then(dataUrl => ({
    id: crypto.randomUUID(),
    user: state.currentUser.name,
    name: file.name,
    image: dataUrl,
    uploadedAt: new Date().toISOString()
  })))).then(entries => {
    state.data.photos.unshift(...entries);
    els.photoFileInput.value = "";
    saveData();
    renderAll();
  });
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function renderPhotos() {
  els.photoGallery.innerHTML = state.data.photos.length ? state.data.photos.map(photo => `
    <figure class="gallery-item">
      <img src="${photo.image}" alt="${photo.name}" />
      <div>${photo.user}<br>${new Date(photo.uploadedAt).toLocaleDateString("en-AU")}</div>
    </figure>`).join("") : '<div class="list-item">No photos uploaded yet.</div>';
}

function renderSettings() {
  renderTagList("drivers", "driversList");
  renderTagList("trucks", "trucksList");
  renderTagList("customers", "customersList");
}

function renderTagList(key, targetId) {
  const container = document.getElementById(targetId);
  container.innerHTML = state.data[key].map((item, index) => `
    <span class="tag">${item} <button data-key="${key}" data-index="${index}">×</button></span>`).join("");
  container.querySelectorAll("button").forEach(btn => btn.addEventListener("click", () => {
    state.data[key].splice(Number(btn.dataset.index), 1);
    saveData();
    renderAll();
  }));
}

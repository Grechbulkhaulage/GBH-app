# Grech Bulk Haulage live deployable app

This is a static deployable prototype for your domain.

## What it includes
- Driver and admin login screen
- Sunday to Saturday roster
- Daily docket form with auto date and auto docket numbering
- Driver clock on / off and time log
- Group chat-style page
- Photo upload gallery
- Admin settings for drivers, trucks and customers
- PWA support for install on phones

## Demo login
- Driver PIN: 1234
- Admin username: admin
- Admin PIN: 1234

## Deploy to your domain

### Option 1: Vercel
1. Upload this folder to a new GitHub repository.
2. Import the repo into Vercel.
3. Framework preset: Other / Static.
4. Deploy.
5. Connect your domain in Vercel settings.

### Option 2: Netlify
1. Drag and drop the folder into Netlify deploys.
2. Connect your domain.

### Option 3: cPanel / shared hosting / GoDaddy
1. Upload all files in this folder into `public_html` or your subdomain folder.
2. Make sure `index.html` stays in the root.
3. Browse to your domain.

## Important note
This version is front-end only.
It stores data in the browser using local storage.
That means:
- logins are demo logins only
- chat is not real-time between devices
- uploads are stored on the device/browser
- dockets are not emailed automatically

## Recommended next production upgrade
To make this fully live across all devices, the next build should add:
- Supabase or Firebase backend
- real user authentication
- real-time chat
- cloud photo storage
- PDF docket generation
- admin reporting dashboard
- push notifications
